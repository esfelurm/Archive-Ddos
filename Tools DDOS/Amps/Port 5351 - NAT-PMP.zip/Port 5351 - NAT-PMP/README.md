# NAT-PMP (NAT Port Mapping Protocol)

## Port: 5351

## Proto: UDP

## Amplification factor: 2-5x

---
