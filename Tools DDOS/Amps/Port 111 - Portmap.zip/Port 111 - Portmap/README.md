# SunRPC/ONC Portmapper (rpcbind)

## Port: 111

## Proto: UDP

## Amplification factor: 15x

---

Abused for years and basically fixed thankfully.
