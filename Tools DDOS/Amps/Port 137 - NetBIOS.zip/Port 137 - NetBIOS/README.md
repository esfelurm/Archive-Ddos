# NetBIOS Service (Name / Datagram / Session)

## Port: 137 (138/139)

## Proto: UDP

## Amplification factor: 4x

---
