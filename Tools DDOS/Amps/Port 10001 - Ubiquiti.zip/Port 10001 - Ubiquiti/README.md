# Ubiquiti (UBNT Discovery on routers)

## Port: 10001

## Proto: UDP

## Amplification factor: ~7x

## Reflector count: ~127,000 (1/1/2020)

---
