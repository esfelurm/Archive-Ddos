# MSSQL (Microsoft SQL Server)

## Port: 1434, 1433

## Proto: UDP

## Amplification factor: 10-30x

---
