# Gucci-Mirai-Botnet
Gucci Mirai Botnet Leak // just clying my space on disk.
