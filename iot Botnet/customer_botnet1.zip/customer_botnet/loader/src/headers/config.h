#pragma once

#define HTTP_SERVER "157.97.105.189"
#define HTTP_PORT 80

#define TFTP_SERVER "157.97.105.189"
